package com.nova.cricketTalk

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.*
import android.net.wifi.WifiManager
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import java.net.*
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ConcurrentLinkedQueue
import kotlin.random.Random

/**
 * Always-on mic + 4-party conference voice over local Wi-Fi (no internet).
 * Each phone broadcasts its own 16 kHz mono PCM frames (20 ms) via UDP to the
 * hotspot subnet and mixes the frames of up to 3 other phones for playback.
 */
class TalkService : Service() {

    companion object {
        const val PORT = 40123
        const val RATE = 16000
        const val FRAME = 320            // 20 ms @ 16 kHz
        const val HEADER = 8             // 4B device id + 4B sequence
        const val MAX_PEERS = 3          // 4 phones total
        const val PREBUFFER = 3          // frames (~60 ms) before playing a peer
        const val MAX_QUEUE = 8          // drop old frames beyond this (limits latency)

        @Volatile var running = false
        @Volatile var muted = false
        @Volatile var peerCount = 0
        @Volatile var error: String? = null
    }

    private class Peer {
        val q = ConcurrentLinkedQueue<ShortArray>()
        @Volatile var last = 0L
        @Volatile var ready = false
    }

    private val myId = Random.nextInt()
    private val peers = ConcurrentHashMap<Int, Peer>()
    private var wakeLock: PowerManager.WakeLock? = null
    private var wifiLock: WifiManager.WifiLock? = null
    private var mcLock: WifiManager.MulticastLock? = null
    private var audioManager: AudioManager? = null
    private var threads = mutableListOf<Thread>()

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (running) return START_STICKY
        startForegroundNotification()
        running = true
        error = null

        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "nova:talk").apply { acquire() }
        val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val mode = if (Build.VERSION.SDK_INT >= 29) WifiManager.WIFI_MODE_FULL_LOW_LATENCY
                   else WifiManager.WIFI_MODE_FULL_HIGH_PERF
        wifiLock = wm.createWifiLock(mode, "nova:wifi").apply { acquire() }
        mcLock = wm.createMulticastLock("nova:mc").apply { acquire() }

        audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        audioManager?.mode = AudioManager.MODE_IN_COMMUNICATION
        audioManager?.isSpeakerphoneOn = true

        threads = mutableListOf(
            Thread { guard { sendLoop() } },
            Thread { guard { receiveLoop() } },
            Thread { guard { playLoop() } }
        ).onEach { it.priority = Thread.MAX_PRIORITY; it.start() }
        return START_STICKY
    }

    private fun guard(block: () -> Unit) {
        try { block() } catch (e: Exception) { if (running) error = e.message ?: e.javaClass.simpleName }
    }

    private fun startForegroundNotification() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("talk", "Cricket Talk", NotificationManager.IMPORTANCE_LOW))
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, "talk")
            .setContentTitle("NOVA Cricket Talk")
            .setContentText("মাইক চালু আছে")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29)
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(1, n)
    }

    /** All broadcast addresses of active interfaces (hotspot interface included). */
    private fun broadcastTargets(): List<InetAddress> {
        val out = mutableListOf<InetAddress>(InetAddress.getByName("255.255.255.255"))
        try {
            for (ni in NetworkInterface.getNetworkInterfaces()) {
                if (!ni.isUp || ni.isLoopback) continue
                for (ia in ni.interfaceAddresses) ia.broadcast?.let { if (it !in out) out.add(it) }
            }
        } catch (_: Exception) {}
        return out
    }

    private fun sendLoop() {
        val min = AudioRecord.getMinBufferSize(RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val rec = AudioRecord(
            MediaRecorder.AudioSource.VOICE_COMMUNICATION, RATE,
            AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(min, FRAME * 8)
        )
        if (AcousticEchoCanceler.isAvailable()) AcousticEchoCanceler.create(rec.audioSessionId)?.enabled = true
        if (NoiseSuppressor.isAvailable()) NoiseSuppressor.create(rec.audioSessionId)?.enabled = true
        if (AutomaticGainControl.isAvailable()) AutomaticGainControl.create(rec.audioSessionId)?.enabled = true

        val sock = DatagramSocket().apply { broadcast = true }
        var targets = broadcastTargets()
        var lastRefresh = System.currentTimeMillis()
        val pcm = ShortArray(FRAME)
        val buf = ByteBuffer.allocate(HEADER + FRAME * 2).order(ByteOrder.LITTLE_ENDIAN)
        var seq = 0

        rec.startRecording()
        try {
            while (running) {
                var got = 0
                while (got < FRAME && running) {
                    val n = rec.read(pcm, got, FRAME - got)
                    if (n <= 0) break
                    got += n
                }
                if (got < FRAME || muted) continue
                buf.clear(); buf.putInt(myId); buf.putInt(seq++)
                buf.asShortBuffer().put(pcm)
                val data = buf.array()
                val now = System.currentTimeMillis()
                if (now - lastRefresh > 3000) { targets = broadcastTargets(); lastRefresh = now }
                for (t in targets) {
                    try { sock.send(DatagramPacket(data, data.size, t, PORT)) } catch (_: Exception) {}
                }
            }
        } finally { rec.stop(); rec.release(); sock.close() }
    }

    private fun receiveLoop() {
        val sock = DatagramSocket(null).apply {
            reuseAddress = true; broadcast = true; soTimeout = 1000
            bind(InetSocketAddress(PORT))
        }
        val pkt = DatagramPacket(ByteArray(2048), 2048)
        try {
            while (running) {
                try { sock.receive(pkt) } catch (_: SocketTimeoutException) { cleanup(); continue }
                if (pkt.length != HEADER + FRAME * 2) continue
                val bb = ByteBuffer.wrap(pkt.data, 0, pkt.length).order(ByteOrder.LITTLE_ENDIAN)
                val id = bb.int; bb.int
                if (id == myId) continue
                var peer = peers[id]
                if (peer == null) {
                    if (peers.size >= MAX_PEERS) continue
                    peer = Peer(); peers[id] = peer
                }
                val f = ShortArray(FRAME); bb.asShortBuffer().get(f)
                peer.last = System.currentTimeMillis()
                peer.q.add(f)
                while (peer.q.size > MAX_QUEUE) peer.q.poll()
                if (peer.q.size >= PREBUFFER) peer.ready = true
                peerCount = peers.size
            }
        } finally { sock.close() }
    }

    private fun cleanup() {
        val now = System.currentTimeMillis()
        peers.entries.removeIf { now - it.value.last > 5000 }
        peerCount = peers.size
    }

    private fun playLoop() {
        val min = AudioTrack.getMinBufferSize(RATE, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val track = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            .setAudioFormat(AudioFormat.Builder().setSampleRate(RATE)
                .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT).build())
            .setBufferSizeInBytes(maxOf(min, FRAME * 2 * 4))
            .setTransferMode(AudioTrack.MODE_STREAM).build()
        val mix = IntArray(FRAME)
        val out = ShortArray(FRAME)
        track.play()
        try {
            while (running) {
                java.util.Arrays.fill(mix, 0)
                for (p in peers.values) {
                    if (!p.ready) continue
                    val f = p.q.poll()
                    if (f == null) { p.ready = false; continue }
                    for (i in 0 until FRAME) mix[i] += f[i].toInt()
                }
                for (i in 0 until FRAME) out[i] = mix[i].coerceIn(-32768, 32767).toShort()
                track.write(out, 0, FRAME)   // blocking write paces the loop in real time
            }
        } finally { track.stop(); track.release() }
    }

    override fun onDestroy() {
        running = false
        peerCount = 0
        peers.clear()
        threads.forEach { try { it.join(1500) } catch (_: Exception) {} }
        audioManager?.mode = AudioManager.MODE_NORMAL
        wakeLock?.let { if (it.isHeld) it.release() }
        wifiLock?.let { if (it.isHeld) it.release() }
        mcLock?.let { if (it.isHeld) it.release() }
        super.onDestroy()
    }
}
