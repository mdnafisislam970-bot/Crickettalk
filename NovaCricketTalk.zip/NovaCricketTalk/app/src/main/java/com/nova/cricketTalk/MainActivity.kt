package com.nova.cricketTalk

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var startBtn: Button
    private lateinit var muteBtn: Button
    private val handler = Handler(Looper.getMainLooper())

    private val ticker = object : Runnable {
        override fun run() { refresh(); handler.postDelayed(this, 500) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(48, 48, 48, 48)
            setBackgroundColor(Color.parseColor("#0B1220"))
        }
        val title = TextView(this).apply {
            text = "NOVA Cricket Talk"; textSize = 26f; setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        status = TextView(this).apply {
            textSize = 16f; setTextColor(Color.parseColor("#9FB3C8"))
            gravity = Gravity.CENTER; setPadding(0, 32, 0, 32)
        }
        startBtn = Button(this).apply { setOnClickListener { toggle() } }
        muteBtn = Button(this).apply {
            setOnClickListener { TalkService.muted = !TalkService.muted; refresh() }
        }
        root.addView(title); root.addView(status); root.addView(startBtn); root.addView(muteBtn)
        setContentView(root)
    }

    override fun onResume() { super.onResume(); handler.post(ticker) }
    override fun onPause() { super.onPause(); handler.removeCallbacks(ticker) }

    private fun toggle() {
        if (TalkService.running) { stopService(Intent(this, TalkService::class.java)); return }
        val need = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) need.add(Manifest.permission.POST_NOTIFICATIONS)
        val missing = need.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isEmpty()) startTalk() else requestPermissions(missing.toTypedArray(), 1)
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) startTalk()
    }

    private fun startTalk() {
        startForegroundService(Intent(this, TalkService::class.java))
    }

    private fun refresh() {
        val on = TalkService.running
        startBtn.text = if (on) "বন্ধ করুন" else "কথা শুরু করুন (মাইক সবসময় চালু)"
        muteBtn.text = if (TalkService.muted) "মিউট বন্ধ করুন" else "মিউট করুন"
        muteBtn.isEnabled = on
        status.text = when {
            TalkService.error != null -> "ত্রুটি: ${TalkService.error}"
            !on -> "বন্ধ আছে"
            else -> "মাইক চালু" + (if (TalkService.muted) " (মিউট)" else "") +
                    "\nসংযুক্ত সদস্য: ${TalkService.peerCount}/3"
        }
    }
}
